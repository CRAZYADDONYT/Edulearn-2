import { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BookOpen, LogOut, User, FileText, Video, GraduationCap,
  Plus, X, Trash2, Loader2, Save, Play, Search, ExternalLink,
} from "lucide-react";
import { useApp, getFileNameFrom, ownerName, type Note, type Lecture, type Course } from "@/context/app-context";

function getViewerUrl(title: string, fallback: string | null) {
  if (fallback) return fallback;
  return `https://www.google.com/search?q=${encodeURIComponent(title)}`;
}

function normalizeYouTubeUrl(url: string | null) {
  if (!url) return null;
  if (url.includes("youtube.com/embed/") || url.includes("youtube-nocookie.com/embed/")) return url;
  const match = url.match(/(?:v=|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
  if (match) return `https://www.youtube.com/embed/${match[1]}`;
  return url;
}

function getDocumentUrl(url: string | null, title: string) {
  if (url) return url;
  return `https://www.google.com/search?q=${encodeURIComponent(title)}`;
}

function isYoutubeUrl(url: string | null) {
  return !!url && /youtu\.be|youtube\.com/.test(url);
}

export default function Dashboard() {
  const { user, logout, notes, lectures, courses, addNote, addLecture, addCourse, deleteNote, deleteLecture, deleteCourse } = useApp();
  const [, navigate] = useLocation();
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState("notes");
  const [isLoading, setIsLoading] = useState(false);
  const [adminError, setAdminError] = useState<string | null>(null);
  const [adminSuccess, setAdminSuccess] = useState<string | null>(null);
  const [courseSubject, setCourseSubject] = useState("");
  const [courseLectureIds, setCourseLectureIds] = useState<string[]>([]);
  const [courseQuery, setCourseQuery] = useState("");
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [selectedLecture, setSelectedLecture] = useState<Lecture | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [selectedNoteUrl, setSelectedNoteUrl] = useState<string | null>(null);

  const [noteData, setNoteData] = useState({ title: "", subject: "", description: "", pages: 0, read_time: "5 min", file_name: "" });
  const [lectureData, setLectureData] = useState({ title: "", subject: "", description: "", video_url: "", duration: "0 min", instructor: ownerName, file_name: "" });
  const [courseData, setCourseData] = useState({ title: "", description: "" });

  useEffect(() => {
    if (!user) navigate("/auth?mode=login");
  }, [user, navigate]);

  const availableSubjects = useMemo(() => Array.from(new Set(lectures.map(lecture => lecture.subject))).sort(), [lectures]);
  const filteredLectures = useMemo(() => lectures.filter(lecture => lecture.subject === courseSubject && lecture.title.toLowerCase().includes(courseQuery.toLowerCase())), [lectures, courseSubject, courseQuery]);
  const selectedLectures = lectures.filter(lecture => courseLectureIds.includes(lecture.id));

  useEffect(() => {
    if (courseSubject) setCourseLectureIds(prev => prev.filter(id => lectures.some(lecture => lecture.id === id && lecture.subject === courseSubject)));
  }, [courseSubject, lectures]);

  if (!user) return null;

  const handleSignOut = () => { logout(); navigate("/"); };

  const withFeedback = (fn: () => void) => {
    setAdminError(null);
    setAdminSuccess(null);
    try { fn(); setAdminSuccess("Saved successfully!"); } catch { setAdminError("Something went wrong."); }
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteData.title || !noteData.subject) return;
    withFeedback(() => {
      addNote({ ...noteData, file_name: noteData.file_name || null });
      setNoteData({ title: "", subject: "", description: "", pages: 0, read_time: "5 min", file_name: "" });
    });
  };

  const handleAddLecture = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lectureData.title || !lectureData.subject) return;
    withFeedback(() => {
      addLecture({ ...lectureData, video_url: lectureData.video_url || null, file_name: lectureData.file_name || null });
      setLectureData({ title: "", subject: "", description: "", video_url: "", duration: "0 min", instructor: ownerName, file_name: "" });
    });
  };

  const handleAddCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseData.title || !courseSubject || courseLectureIds.length === 0) return;
    withFeedback(() => {
      addCourse({ title: courseData.title, subject: courseSubject, description: courseData.description, total_lessons: courseLectureIds.length, lecture_ids: courseLectureIds });
      setCourseData({ title: "", description: "" });
      setCourseSubject("");
      setCourseLectureIds([]);
      setCourseQuery("");
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center"><BookOpen className="w-5 h-5 text-primary-foreground" /></div>
              <span className="text-xl font-semibold tracking-tight">EduLearn</span>
            </Link>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted text-sm font-medium">
                <User className="w-4 h-4" />
                {user.name}
                {user.isOwner && <span className="ml-1 px-1.5 py-0.5 text-xs rounded bg-accent text-accent-foreground font-semibold">Owner</span>}
              </div>
              <Button variant="outline" size="sm" onClick={handleSignOut}><LogOut className="w-4 h-4 mr-2" />Sign out</Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="mb-8 flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-bold">Welcome back, {user.name}</h1>
            <p className="text-muted-foreground mt-1">{user.isOwner ? "You have owner access — manage content from the admin panel below." : "Continue your learning journey."}</p>
          </div>
          {user.isOwner && !showAdminPanel && <Button onClick={() => setShowAdminPanel(true)}><Plus className="w-4 h-4 mr-2" />Admin Panel</Button>}
        </div>

        {selectedNote && (
          <Card className="mb-8 border-accent/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>{selectedNote.title}</CardTitle>
                <CardDescription>{selectedNote.subject} • {selectedNote.pages} pages</CardDescription>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setSelectedNote(null)}><X className="w-4 h-4" /></Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border bg-muted/30 p-4 whitespace-pre-wrap text-sm leading-6">
                {selectedNote.description || "No description available."}
              </div>
              {selectedNote.file_name && <div className="text-sm text-muted-foreground">File: {selectedNote.file_name}</div>}
              <div className="flex gap-2">
                <Button onClick={() => setSelectedNoteUrl(getDocumentUrl(selectedNote.file_name, selectedNote.title))}>
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open note
                </Button>
              </div>
              {selectedNoteUrl && (
                <div className="aspect-[4/3] rounded-lg overflow-hidden border bg-background">
                  <iframe title={selectedNote.title} src={selectedNoteUrl} className="h-full w-full" />
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {selectedLecture && (
          <Card className="mb-8 border-accent/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>{selectedLecture.title}</CardTitle>
                <CardDescription>{selectedLecture.subject} • {selectedLecture.duration}</CardDescription>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setSelectedLecture(null)}><X className="w-4 h-4" /></Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="aspect-video rounded-lg overflow-hidden border bg-black">
                {normalizeYouTubeUrl(selectedLecture.video_url) && isYoutubeUrl(selectedLecture.video_url) ? (
                  <iframe title={selectedLecture.title} src={normalizeYouTubeUrl(selectedLecture.video_url) ?? ""} className="h-full w-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
                ) : (
                  <div className="h-full w-full flex items-center justify-center text-white/80 text-sm">No video URL yet</div>
                )}
              </div>
              <div className="text-sm text-muted-foreground">{selectedLecture.description || "No description available."}</div>
            </CardContent>
          </Card>
        )}

        {selectedCourse && (
          <Card className="mb-8 border-accent/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>{selectedCourse.title}</CardTitle>
                <CardDescription>{selectedCourse.subject} • {selectedCourse.total_lessons} lectures</CardDescription>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setSelectedCourse(null)}><X className="w-4 h-4" /></Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                {selectedCourse.lecture_ids.map(id => {
                  const lecture = lectures.find(item => item.id === id);
                  if (!lecture) return null;
                  return (
                    <button key={id} className="text-left rounded-lg border p-3 hover:bg-muted" onClick={() => setSelectedLecture(lecture)}>
                      <div className="font-medium text-sm">{lecture.title}</div>
                      <div className="text-xs text-muted-foreground">{lecture.duration}</div>
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {user.isOwner && showAdminPanel && (
          <Card className="mb-8 border-accent/50 animate-in fade-in slide-in-from-top-4 duration-300">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2"><Plus className="w-5 h-5" />Admin Panel — Content Management</CardTitle>
                <CardDescription>Add and manage notes, lectures, and courses</CardDescription>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setShowAdminPanel(false)}><X className="w-4 h-4" /></Button>
            </CardHeader>
            <CardContent>
              {adminError && <div className="mb-4 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">{adminError}</div>}
              {adminSuccess && <div className="mb-4 p-3 rounded-lg bg-green-500/10 border border-green-500/20 text-green-700 text-sm">{adminSuccess}</div>}
              <Tabs value={activeAdminTab} onValueChange={setActiveAdminTab}>
                <TabsList className="grid w-full grid-cols-3 mb-6">
                  <TabsTrigger value="notes" className="flex items-center gap-2"><FileText className="w-4 h-4" />Notes</TabsTrigger>
                  <TabsTrigger value="lectures" className="flex items-center gap-2"><Video className="w-4 h-4" />Lectures</TabsTrigger>
                  <TabsTrigger value="courses" className="flex items-center gap-2"><GraduationCap className="w-4 h-4" />Courses</TabsTrigger>
                </TabsList>

                <TabsContent value="notes">
                  <div className="grid md:grid-cols-2 gap-6">
                    <form onSubmit={handleAddNote} className="space-y-4">
                      <h3 className="font-semibold">Upload Note from File</h3>
                      <div className="space-y-2"><Label>Upload from files</Label><Input type="file" accept=".pdf,.doc,.docx,.txt,.md" onChange={e => setNoteData({ ...noteData, file_name: e.target.files?.[0] ? getFileNameFrom(e.target.files[0].name) : "" })} /></div>
                      <div className="space-y-2"><Label>Title</Label><Input value={noteData.title} onChange={e => setNoteData({ ...noteData, title: e.target.value })} required disabled={isLoading} /></div>
                      <div className="space-y-2"><Label>Subject</Label><Input value={noteData.subject} onChange={e => setNoteData({ ...noteData, subject: e.target.value })} required disabled={isLoading} /></div>
                      <div className="space-y-2"><Label>Description</Label><Textarea value={noteData.description} onChange={e => setNoteData({ ...noteData, description: e.target.value })} disabled={isLoading} /></div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2"><Label>Pages</Label><Input type="number" value={noteData.pages} onChange={e => setNoteData({ ...noteData, pages: parseInt(e.target.value) || 0 })} disabled={isLoading} /></div>
                        <div className="space-y-2"><Label>Read Time</Label><Input value={noteData.read_time} onChange={e => setNoteData({ ...noteData, read_time: e.target.value })} disabled={isLoading} /></div>
                      </div>
                      <Button type="submit">{<Save className="w-4 h-4 mr-2" />}Add Note</Button>
                    </form>
                    <div>
                      <h3 className="font-semibold mb-4">Existing Notes ({notes.length})</h3>
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {notes.map(note => <button key={note.id} className="w-full flex items-center justify-between p-3 bg-muted/50 rounded-lg gap-3 text-left hover:bg-muted" onClick={() => { setSelectedNote(note); setSelectedNoteUrl(getDocumentUrl(note.file_name, note.title)); }}><div className="min-w-0"><p className="font-medium text-sm truncate">{note.title}</p><p className="text-xs text-muted-foreground truncate">{note.subject}{note.file_name ? ` • ${note.file_name}` : ""}</p></div><Trash2 className="w-4 h-4 text-destructive shrink-0" onClick={e => { e.stopPropagation(); deleteNote(note.id); }} /></button>)}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="lectures">
                  <div className="grid md:grid-cols-2 gap-6">
                    <form onSubmit={handleAddLecture} className="space-y-4">
                      <h3 className="font-semibold">Upload Lecture from File</h3>
                      <div className="space-y-2"><Label>Upload from files</Label><Input type="file" accept="video/*" onChange={e => setLectureData({ ...lectureData, file_name: e.target.files?.[0] ? getFileNameFrom(e.target.files[0].name) : "" })} /></div>
                      <div className="space-y-2"><Label>Title</Label><Input value={lectureData.title} onChange={e => setLectureData({ ...lectureData, title: e.target.value })} required disabled={isLoading} /></div>
                      <div className="space-y-2"><Label>Subject</Label><Input value={lectureData.subject} onChange={e => setLectureData({ ...lectureData, subject: e.target.value })} required disabled={isLoading} /></div>
                      <div className="space-y-2"><Label>Video URL</Label><Input value={lectureData.video_url} onChange={e => setLectureData({ ...lectureData, video_url: e.target.value })} placeholder="https://youtube.com/..." disabled={isLoading} /></div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2"><Label>Duration</Label><Input value={lectureData.duration} onChange={e => setLectureData({ ...lectureData, duration: e.target.value })} disabled={isLoading} /></div>
                        <div className="space-y-2"><Label>Instructor</Label><Input value={lectureData.instructor} onChange={e => setLectureData({ ...lectureData, instructor: e.target.value })} disabled={isLoading} /></div>
                      </div>
                      <Button type="submit"><Save className="w-4 h-4 mr-2" />Add Lecture</Button>
                    </form>
                    <div>
                      <h3 className="font-semibold mb-4">Existing Lectures ({lectures.length})</h3>
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {lectures.map(lecture => <button key={lecture.id} className="w-full flex items-center justify-between p-3 bg-muted/50 rounded-lg gap-3 text-left hover:bg-muted" onClick={() => setSelectedLecture(lecture)}><div className="min-w-0"><p className="font-medium text-sm truncate">{lecture.title}</p><p className="text-xs text-muted-foreground truncate">{lecture.subject} • {lecture.duration}{lecture.file_name ? ` • ${lecture.file_name}` : ""}</p></div><Trash2 className="w-4 h-4 text-destructive shrink-0" onClick={e => { e.stopPropagation(); deleteLecture(lecture.id); }} /></button>)}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="courses">
                  <div className="grid md:grid-cols-2 gap-6">
                    <form onSubmit={handleAddCourse} className="space-y-4">
                      <h3 className="font-semibold">Create Course from Lectures</h3>
                      <div className="space-y-2"><Label>Title</Label><Input value={courseData.title} onChange={e => setCourseData({ ...courseData, title: e.target.value })} required disabled={isLoading} /></div>
                      <div className="space-y-2"><Label>Description</Label><Textarea value={courseData.description} onChange={e => setCourseData({ ...courseData, description: e.target.value })} disabled={isLoading} /></div>
                      <div className="space-y-2"><Label>Subject</Label><select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={courseSubject} onChange={e => setCourseSubject(e.target.value)}><option value="">Select subject</option>{availableSubjects.map(subject => <option key={subject} value={subject}>{subject}</option>)}</select></div>
                      <div className="space-y-2"><Label>Browse lectures</Label><div className="relative"><Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" /><Input className="pl-9" placeholder="Search within the subject" value={courseQuery} onChange={e => setCourseQuery(e.target.value)} disabled={!courseSubject} /></div></div>
                      <div className="space-y-2 max-h-72 overflow-y-auto rounded-lg border p-3">
                        {!courseSubject ? <p className="text-sm text-muted-foreground">Pick a subject to browse lectures.</p> : filteredLectures.length === 0 ? <p className="text-sm text-muted-foreground">No lectures found for this subject.</p> : filteredLectures.map(lecture => <label key={lecture.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted cursor-pointer"><input type="checkbox" className="mt-1" checked={courseLectureIds.includes(lecture.id)} onChange={e => setCourseLectureIds(prev => e.target.checked ? [...prev, lecture.id] : prev.filter(id => id !== lecture.id))} /><div><p className="text-sm font-medium">{lecture.title}</p><p className="text-xs text-muted-foreground">{lecture.duration}{lecture.file_name ? ` • ${lecture.file_name}` : ""}</p></div></label>)}
                      </div>
                      <div className="text-sm text-muted-foreground">Selected lectures: {selectedLectures.length}</div>
                      <Button type="submit" disabled={!courseSubject || courseLectureIds.length === 0}><Save className="w-4 h-4 mr-2" />Add Course</Button>
                    </form>
                    <div>
                      <h3 className="font-semibold mb-4">Existing Courses ({courses.length})</h3>
                      <div className="space-y-3 max-h-[42rem] overflow-y-auto">
                        {courses.map(course => <button key={course.id} className="w-full p-3 bg-muted/50 rounded-lg text-left hover:bg-muted" onClick={() => setSelectedCourse(course)}><div className="flex items-center justify-between gap-3"><div><p className="font-medium text-sm">{course.title}</p><p className="text-xs text-muted-foreground">{course.subject} • {course.total_lessons} lectures</p></div><Trash2 className="w-4 h-4 text-destructive shrink-0" onClick={e => { e.stopPropagation(); deleteCourse(course.id); }} /></div><div className="mt-3 flex flex-wrap gap-2">{course.lecture_ids.map(id => { const lecture = lectures.find(item => item.id === id); return lecture ? <span key={id} className="text-xs px-2 py-1 rounded-full bg-background border">{lecture.title}</span> : null; })}</div></button>)}
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader><div className="flex items-center justify-between"><div className="flex items-center gap-2"><FileText className="w-5 h-5 text-accent" /><CardTitle>Notes</CardTitle></div><span className="text-sm text-muted-foreground">{notes.length} available</span></div><CardDescription>Study materials curated by the owner</CardDescription></CardHeader>
            <CardContent>
              {notes.length === 0 ? <div className="text-center py-8 text-muted-foreground"><FileText className="w-12 h-12 mx-auto mb-3 opacity-50" /><p>No notes available yet</p></div> : <div className="space-y-3">{notes.slice(0, 5).map(note => <div key={note.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"><div><p className="font-medium">{note.title}</p><p className="text-sm text-muted-foreground">{note.subject} • {note.pages} pages</p></div><Button size="sm" variant="ghost" onClick={() => setSelectedNote(note)}>Read</Button></div>)}</div>}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><div className="flex items-center justify-between"><div className="flex items-center gap-2"><Video className="w-5 h-5 text-accent" /><CardTitle>Video Lectures</CardTitle></div><span className="text-sm text-muted-foreground">{lectures.length} available</span></div><CardDescription>Watch expert-led video content</CardDescription></CardHeader>
            <CardContent>
              {lectures.length === 0 ? <div className="text-center py-8 text-muted-foreground"><Video className="w-12 h-12 mx-auto mb-3 opacity-50" /><p>No lectures available yet</p></div> : <div className="space-y-3">{lectures.slice(0, 5).map(lecture => <div key={lecture.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"><div><p className="font-medium">{lecture.title}</p><p className="text-sm text-muted-foreground">{lecture.subject} • {lecture.duration}</p></div><Button size="sm" variant="ghost" onClick={() => setSelectedLecture(lecture)}><Play className="w-4 h-4 mr-2" />Watch</Button></div>)}</div>}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
