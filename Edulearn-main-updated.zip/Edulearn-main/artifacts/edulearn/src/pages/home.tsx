import { useState } from "react";
import { Header } from "@/components/header";
import { HeroSection } from "@/components/hero-section";
import { NotesSection } from "@/components/notes-section";
import { LecturesSection } from "@/components/lectures-section";
import { Footer } from "@/components/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Play, FileText, ExternalLink } from "lucide-react";
import { useApp, type Note, type Lecture, type Course } from "@/context/app-context";

function NoteReader({ note, onClose }: { note: Note; onClose: () => void }) {
  return (
    <Card className="mb-8 border-accent/50">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>{note.title}</CardTitle>
          <CardDescription>{note.subject} • {note.pages} pages</CardDescription>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}><X className="w-4 h-4" /></Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-lg border bg-muted/30 p-4 whitespace-pre-wrap text-sm leading-6">{note.description || "No description available."}</div>
        {note.file_name && <div className="text-sm text-muted-foreground">File: {note.file_name}</div>}
        <Button asChild><a href={`https://www.google.com/search?q=${encodeURIComponent(note.title)}`} target="_blank" rel="noreferrer"><ExternalLink className="w-4 h-4 mr-2" />Open note</a></Button>
      </CardContent>
    </Card>
  );
}

function LecturePlayer({ lecture, onClose }: { lecture: Lecture; onClose: () => void }) {
  return (
    <Card className="mb-8 border-accent/50">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>{lecture.title}</CardTitle>
          <CardDescription>{lecture.subject} • {lecture.duration}</CardDescription>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}><X className="w-4 h-4" /></Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="aspect-video rounded-lg overflow-hidden border bg-black">
          {lecture.video_url ? (
            <iframe title={lecture.title} src={lecture.video_url} className="h-full w-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
          ) : (
            <div className="h-full w-full flex items-center justify-center text-white/80 text-sm">No video URL yet</div>
          )}
        </div>
        <div className="text-sm text-muted-foreground">{lecture.description || "No description available."}</div>
      </CardContent>
    </Card>
  );
}

function CoursePlayer({ course, lectures, onClose, onPickLecture }: { course: Course; lectures: Lecture[]; onClose: () => void; onPickLecture: (lecture: Lecture) => void }) {
  return (
    <Card className="mb-8 border-accent/50">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>{course.title}</CardTitle>
          <CardDescription>{course.subject} • {course.total_lessons} lectures</CardDescription>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}><X className="w-4 h-4" /></Button>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-4">
          {course.lecture_ids.map(id => {
            const lecture = lectures.find(item => item.id === id);
            if (!lecture) return null;
            return (
              <button key={id} className="text-left rounded-lg border p-3 hover:bg-muted" onClick={() => onPickLecture(lecture)}>
                <div className="font-medium text-sm">{lecture.title}</div>
                <div className="text-xs text-muted-foreground">{lecture.duration}</div>
              </button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

export default function Home() {
  const { notes, lectures, courses } = useApp();
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [selectedLecture, setSelectedLecture] = useState<Lecture | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  return (
    <main className="min-h-screen">
      <Header />
      <HeroSection />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8 space-y-6">
        {selectedNote && <NoteReader note={selectedNote} onClose={() => setSelectedNote(null)} />}
        {selectedLecture && <LecturePlayer lecture={selectedLecture} onClose={() => setSelectedLecture(null)} />}
        {selectedCourse && <CoursePlayer course={selectedCourse} lectures={lectures} onClose={() => setSelectedCourse(null)} onPickLecture={setSelectedLecture} />}
      </div>
      <div id="notes"><NotesSection /></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-6"><div className="flex justify-end"><Button variant="outline" onClick={() => setSelectedNote(notes[0] ?? null)}><FileText className="w-4 h-4 mr-2" />Open first note</Button></div></div>
      <div id="lectures"><LecturesSection /></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6"><div className="flex flex-wrap gap-3"><Button onClick={() => setSelectedLecture(lectures[0] ?? null)}><Play className="w-4 h-4 mr-2" />Open first lecture</Button><Button variant="outline" onClick={() => setSelectedCourse(courses[0] ?? null)}>Open first course</Button></div></div>
      <Footer />
    </main>
  );
}
