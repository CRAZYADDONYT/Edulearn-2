import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from "react";

export interface Note {
  id: string;
  title: string;
  subject: string;
  description: string | null;
  pages: number;
  read_time: string;
  downloads: number;
  created_at: string;
  file_name: string | null;
}

export interface Lecture {
  id: string;
  title: string;
  subject: string;
  description: string | null;
  video_url: string | null;
  duration: string;
  instructor: string;
  students: number;
  created_at: string;
  file_name: string | null;
}

export interface Course {
  id: string;
  title: string;
  subject: string;
  description: string | null;
  total_lessons: number;
  created_at: string;
  lecture_ids: string[];
}

export interface AppUser {
  id: string;
  name: string;
  email: string;
  isOwner: boolean;
}

interface AppContextType {
  user: AppUser | null;
  notes: Note[];
  lectures: Lecture[];
  courses: Course[];
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  addNote: (note: Omit<Note, "id" | "created_at" | "downloads">) => void;
  addLecture: (lecture: Omit<Lecture, "id" | "created_at" | "students">) => void;
  addCourse: (course: Omit<Course, "id" | "created_at">) => void;
  deleteNote: (id: string) => void;
  deleteLecture: (id: string) => void;
  deleteCourse: (id: string) => void;
}

const OWNER_EMAIL = "owner@edulearn.com";
const OWNER_NAME = "Owner";

const initialNotes: Note[] = [
  {
    id: "n1",
    title: "Introduction to Calculus",
    subject: "Mathematics",
    description: "Covering limits, derivatives and integrals with worked examples.",
    pages: 24,
    read_time: "45 min",
    downloads: 312,
    created_at: "2026-03-01",
    file_name: null,
  },
  {
    id: "n2",
    title: "Organic Chemistry Fundamentals",
    subject: "Chemistry",
    description: "Bonding, nomenclature, and reaction mechanisms explained clearly.",
    pages: 18,
    read_time: "35 min",
    downloads: 204,
    created_at: "2026-03-10",
    file_name: null,
  },
  {
    id: "n3",
    title: "World History: 20th Century",
    subject: "History",
    description: "Key events, movements, and turning points of the modern era.",
    pages: 30,
    read_time: "1 hr",
    downloads: 189,
    created_at: "2026-03-15",
    file_name: null,
  },
];

const initialLectures: Lecture[] = [
  {
    id: "l1",
    title: "Linear Algebra — Vectors & Matrices",
    subject: "Mathematics",
    description: "A hands-on introduction to linear transformations and matrix operations.",
    video_url: null,
    duration: "52 min",
    instructor: OWNER_NAME,
    students: 1240,
    created_at: "2026-02-20",
    file_name: null,
  },
  {
    id: "l2",
    title: "The Laws of Thermodynamics",
    subject: "Physics",
    description: "Entropy, energy transfer, and real-world applications explained.",
    video_url: null,
    duration: "40 min",
    instructor: OWNER_NAME,
    students: 876,
    created_at: "2026-02-28",
    file_name: null,
  },
  {
    id: "l3",
    title: "Data Structures & Algorithms",
    subject: "Computer Science",
    description: "Trees, graphs, sorting algorithms — with complexity analysis.",
    video_url: null,
    duration: "65 min",
    instructor: OWNER_NAME,
    students: 2031,
    created_at: "2026-03-05",
    file_name: null,
  },
];

const initialCourses: Course[] = [
  {
    id: "c1",
    title: "Complete Python Programming",
    subject: "Computer Science",
    description: "From beginner to advanced Python — covering OOP, file I/O, and APIs.",
    total_lessons: 42,
    created_at: "2026-01-15",
    lecture_ids: ["l3"],
  },
  {
    id: "c2",
    title: "High School Mathematics",
    subject: "Mathematics",
    description: "Algebra, geometry, trigonometry, and introductory calculus.",
    total_lessons: 58,
    created_at: "2026-01-20",
    lecture_ids: ["l1"],
  },
];

const AppContext = createContext<AppContextType | null>(null);
const STORAGE_KEY = "edulearn.local-state";

const FAKE_USERS: Record<string, { name: string; password: string }> = {
  [OWNER_EMAIL]: { name: OWNER_NAME, password: "owner123" },
};

function fileNameFrom(value: string) {
  return value.split("/").pop() || value;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [notes, setNotes] = useState<Note[]>(initialNotes);
  const [lectures, setLectures] = useState<Lecture[]>(initialLectures);
  const [courses, setCourses] = useState<Course[]>(initialCourses);
  const [registeredUsers, setRegisteredUsers] = useState<Record<string, { name: string; password: string }>>(FAKE_USERS);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as {
          notes?: Note[];
          lectures?: Lecture[];
          courses?: Course[];
          registeredUsers?: Record<string, { name: string; password: string }>;
          user?: AppUser | null;
        };
        if (parsed.notes) setNotes(parsed.notes);
        if (parsed.lectures) setLectures(parsed.lectures);
        if (parsed.courses) setCourses(parsed.courses);
        if (parsed.registeredUsers) setRegisteredUsers(parsed.registeredUsers);
        if (parsed.user) setUser(parsed.user);
      }
    } catch {}
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ notes, lectures, courses, registeredUsers, user }));
  }, [notes, lectures, courses, registeredUsers, user, hydrated]);

  const login = useCallback(async (email: string, password: string) => {
    const found = registeredUsers[email.toLowerCase()];
    if (!found) return { success: false, error: "No account found with that email." };
    if (found.password !== password) return { success: false, error: "Incorrect password." };
    setUser({
      id: email,
      name: found.name,
      email: email.toLowerCase(),
      isOwner: email.toLowerCase() === OWNER_EMAIL,
    });
    return { success: true };
  }, [registeredUsers]);

  const signup = useCallback(async (name: string, email: string, password: string) => {
    const key = email.toLowerCase();
    if (registeredUsers[key]) return { success: false, error: "An account with that email already exists." };
    if (password.length < 6) return { success: false, error: "Password must be at least 6 characters." };
    setRegisteredUsers(prev => ({ ...prev, [key]: { name, password } }));
    setUser({
      id: key,
      name,
      email: key,
      isOwner: key === OWNER_EMAIL,
    });
    return { success: true };
  }, [registeredUsers]);

  const logout = useCallback(() => setUser(null), []);

  const addNote = useCallback((note: Omit<Note, "id" | "created_at" | "downloads">) => {
    setNotes(prev => [{
      ...note,
      id: `n${Date.now()}`,
      downloads: 0,
      created_at: new Date().toISOString(),
      file_name: note.file_name ?? null,
    }, ...prev]);
  }, []);

  const addLecture = useCallback((lecture: Omit<Lecture, "id" | "created_at" | "students">) => {
    setLectures(prev => [{
      ...lecture,
      id: `l${Date.now()}`,
      students: 0,
      created_at: new Date().toISOString(),
      file_name: lecture.file_name ?? null,
    }, ...prev]);
  }, []);

  const addCourse = useCallback((course: Omit<Course, "id" | "created_at">) => {
    setCourses(prev => [{
      ...course,
      id: `c${Date.now()}`,
      created_at: new Date().toISOString(),
    }, ...prev]);
  }, []);

  const deleteNote = useCallback((id: string) => setNotes(prev => prev.filter(n => n.id !== id)), []);
  const deleteLecture = useCallback((id: string) => setLectures(prev => prev.filter(l => l.id !== id)), []);
  const deleteCourse = useCallback((id: string) => setCourses(prev => prev.filter(c => c.id !== id)), []);

  return (
    <AppContext.Provider value={{
      user, notes, lectures, courses,
      login, signup, logout,
      addNote, addLecture, addCourse,
      deleteNote, deleteLecture, deleteCourse,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

export const ownerEmail = OWNER_EMAIL;
export const ownerName = OWNER_NAME;
export const getFileNameFrom = fileNameFrom;
