import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { TrendingUp, Target, Award, Flame, UserPlus } from "lucide-react";
import { useApp } from "@/context/app-context";

export function ProgressSection() {
  const { user, courses, progress } = useApp();

  return (
    <section className="py-20 md:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-medium text-accent uppercase tracking-wider">Track Your Journey</span>
          <h2 className="mt-2 text-3xl md:text-4xl font-bold tracking-tight">Your Learning Progress</h2>
          <p className="mt-3 text-muted-foreground">
            {user ? "Your learning stats and course progress at a glance." : "Sign in to track your learning journey and earn achievement milestones."}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-2 animate-in fade-in slide-in-from-left-4 duration-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-accent" />
                Course Progress
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {user && courses.length > 0 ? (
                courses.map(course => {
                  const cp = progress.find(p => p.course_id === course.id);
                  const pct = cp?.progress_percent ?? 0;
                  return (
                    <div key={course.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{course.title}</span>
                        <span className="text-sm text-muted-foreground">{pct}%</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Progress value={pct} className="h-2 flex-1" />
                        <span className="text-sm font-medium w-12 text-right">{pct}%</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{course.total_lessons} lessons</p>
                    </div>
                  );
                })
              ) : (
                <>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-muted-foreground">No courses started</span>
                      <span className="text-sm text-muted-foreground">0/0 lessons</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Progress value={0} className="h-2 flex-1" />
                      <span className="text-sm font-medium w-12 text-right text-muted-foreground">0%</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-muted-foreground">Sign in to track progress</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Progress value={0} className="h-2 flex-1" />
                      <span className="text-sm font-medium w-12 text-right text-muted-foreground">0%</span>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <div className="space-y-4">
            <Card className="animate-in fade-in slide-in-from-right-4 duration-700 delay-100">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Target className="w-4 h-4" />
                    <span className="text-sm font-medium">Daily Goal</span>
                  </div>
                  <span className="text-2xl font-bold text-foreground">{user ? "3/5" : "—"}</span>
                </div>
                <Progress value={user ? 60 : 0} className="h-1.5" />
                <p className="text-xs text-muted-foreground mt-2">{user ? "3 of 5 lessons today" : "Sign in to set goals"}</p>
              </CardContent>
            </Card>

            <Card className="animate-in fade-in slide-in-from-right-4 duration-700 delay-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Flame className="w-4 h-4" />
                    <span className="text-sm font-medium">Streak</span>
                  </div>
                  <span className="text-2xl font-bold text-foreground">{user ? "7" : "—"}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-2">{user ? "7-day learning streak!" : "Sign in to build streaks"}</p>
              </CardContent>
            </Card>

            <Card className="animate-in fade-in slide-in-from-right-4 duration-700 delay-300">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Award className="w-4 h-4" />
                    <span className="text-sm font-medium">Achievements</span>
                  </div>
                  <span className="text-2xl font-bold text-foreground">{user ? "4" : "—"}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-2">{user ? "4 badges earned" : "Sign in to earn badges"}</p>
              </CardContent>
            </Card>

            {!user && (
              <Button asChild className="w-full group animate-in fade-in slide-in-from-right-4 duration-700 delay-400">
                <Link href="/auth">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Sign up to track progress
                </Link>
              </Button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
