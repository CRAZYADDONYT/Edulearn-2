import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Video, Lock, ArrowRight, Play, Users } from "lucide-react";
import { useApp } from "@/context/app-context";

export function LecturesSection() {
  const { lectures } = useApp();
  const hasLectures = lectures.length > 0;

  return (
    <section className="py-20 md:py-32 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12">
          <div>
            <span className="text-sm font-medium text-accent uppercase tracking-wider">Video Learning</span>
            <h2 className="mt-2 text-3xl md:text-4xl font-bold tracking-tight">Video Lectures</h2>
            <p className="mt-3 text-muted-foreground max-w-xl">
              High-quality video content uploaded exclusively by our team.
            </p>
          </div>
          {hasLectures && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Lock className="w-4 h-4" />
              <span>Owner-uploaded content</span>
            </div>
          )}
        </div>

        {hasLectures ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {lectures.map((lecture, index) => (
              <Card
                key={lecture.id}
                className="group hover:shadow-lg transition-all duration-300 overflow-hidden animate-in fade-in slide-in-from-bottom-4"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="relative aspect-video bg-muted">
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-accent/20 to-accent/5">
                    <Video className="w-12 h-12 text-accent/50" />
                  </div>
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-14 h-14 rounded-full bg-white/90 flex items-center justify-center">
                      <Play className="w-6 h-6 text-accent fill-accent" />
                    </div>
                  </div>
                  <span className="absolute bottom-2 right-2 px-2 py-1 rounded bg-black/70 text-white text-xs font-medium">
                    {lecture.duration}
                  </span>
                </div>
                <CardContent className="p-5">
                  <span className="text-xs font-medium px-2 py-1 rounded-full bg-muted text-muted-foreground">
                    {lecture.subject}
                  </span>
                  <h3 className="mt-3 text-lg font-semibold group-hover:text-accent transition-colors line-clamp-2">
                    {lecture.title}
                  </h3>
                  {lecture.description && (
                    <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{lecture.description}</p>
                  )}
                  <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
                    <span>{lecture.instructor}</span>
                    <span className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {lecture.students.toLocaleString()} students
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="animate-in fade-in slide-in-from-bottom-4 duration-700">
            <CardContent className="flex flex-col items-center justify-center py-16 md:py-24 text-center">
              <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-6">
                <Video className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-2">No lectures available yet</h3>
              <p className="text-muted-foreground max-w-md mb-6">
                Video lectures will be uploaded soon. Sign up to get notified when new content becomes available.
              </p>
              <Button asChild className="group">
                <Link href="/auth">
                  Sign up for updates
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <div className="mt-8 flex items-center gap-2 text-sm text-muted-foreground">
                <Lock className="w-4 h-4" />
                <span>Only the site owner can upload lectures</span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </section>
  );
}
