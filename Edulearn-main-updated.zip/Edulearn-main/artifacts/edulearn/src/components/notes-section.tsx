import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Lock, ArrowRight, Download, Clock, ExternalLink } from "lucide-react";
import { useApp } from "@/context/app-context";

export function NotesSection() {
  const { notes } = useApp();
  const hasNotes = notes.length > 0;

  const openPdfInViewer = (fileName: string | null) => {
    if (!fileName) {
      alert("PDF file not uploaded yet.");
      return;
    }

    const pdfUrl = `/uploads/${fileName}`;
    window.open(
      `https://docs.google.com/gview?embedded=true&url=${window.location.origin}${pdfUrl}`,
      "_blank"
    );
  };

  return (
    <section className="py-20 md:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12">
          <div>
            <span className="text-sm font-medium text-accent uppercase tracking-wider">Study Materials</span>
            <h2 className="mt-2 text-3xl md:text-4xl font-bold tracking-tight">Course Notes</h2>
            <p className="mt-3 text-muted-foreground max-w-xl">
              Expertly crafted notes uploaded exclusively by the site owner.
            </p>
          </div>
          {hasNotes && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Lock className="w-4 h-4" />
              <span>Owner-uploaded content</span>
            </div>
          )}
        </div>

        {hasNotes ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {notes.map((note, index) => (
              <Card
                key={note.id}
                className="group hover:shadow-lg transition-all duration-300 animate-in fade-in slide-in-from-bottom-4"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 rounded-xl bg-accent/10">
                      <FileText className="w-6 h-6 text-accent" />
                    </div>
                    <span className="text-xs font-medium px-2 py-1 rounded-full bg-muted text-muted-foreground">
                      {note.subject}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2 group-hover:text-accent transition-colors">
                    {note.title}
                  </h3>
                  {note.description && (
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{note.description}</p>
                  )}
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center gap-4">
                      <span>{note.pages} pages</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {note.read_time}
                      </span>
                    </div>
                    <span className="flex items-center gap-1">
                      <Download className="w-3 h-3" />
                      {note.downloads}
                    </span>
                  </div>

                  <Button
                    onClick={() => openPdfInViewer(note.file_name)}
                    className="w-full mt-5 group"
                    variant="secondary"
                  >
                    Open Notes
                    <ExternalLink className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="animate-in fade-in slide-in-from-bottom-4 duration-700">
            <CardContent className="flex flex-col items-center justify-center py-16 md:py-24 text-center">
              <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-6">
                <FileText className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-2">No notes available yet</h3>
              <p className="text-muted-foreground max-w-md mb-6">
                Course notes will be uploaded soon. Sign up to get notified when new materials become available.
              </p>
              <Button asChild className="group">
                <Link href="/auth">
                  Sign up for updates
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <div className="mt-8 flex items-center gap-2 text-sm text-muted-foreground">
                <Lock className="w-4 h-4" />
                <span>Only the site owner can upload notes</span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </section>
  );
}
