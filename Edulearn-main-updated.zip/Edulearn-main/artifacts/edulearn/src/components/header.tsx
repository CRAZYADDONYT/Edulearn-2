import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X, BookOpen, LogOut, User } from "lucide-react";
import { useApp } from "@/context/app-context";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout } = useApp();
  const [, navigate] = useLocation();

  const handleSignOut = () => {
    logout();
    navigate("/");
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold tracking-tight">EduLearn</span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-sm font-medium text-foreground hover:text-accent transition-colors">
              Home
            </Link>
            <a href="#notes" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Notes
            </a>
            <a href="#lectures" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Lectures
            </a>
            <a href="#progress" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Progress
            </a>
          </nav>

          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <>
                <Button asChild variant="ghost" size="sm" className="text-sm font-medium">
                  <Link href="/dashboard">
                    <User className="w-4 h-4 mr-2" />
                    Dashboard
                  </Link>
                </Button>
                <Button variant="outline" size="sm" className="text-sm font-medium" onClick={handleSignOut}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign out
                </Button>
              </>
            ) : (
              <>
                <Button asChild variant="ghost" size="sm" className="text-sm font-medium">
                  <Link href="/auth?mode=login">Log in</Link>
                </Button>
                <Button asChild size="sm" className="text-sm font-medium">
                  <Link href="/auth?mode=signup">Sign up</Link>
                </Button>
              </>
            )}
          </div>

          <button
            className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden bg-background border-b border-border animate-in slide-in-from-top-2 duration-200">
          <div className="px-4 py-4 space-y-3">
            <Link
              href="/"
              className="block px-3 py-2 text-sm font-medium rounded-lg hover:bg-muted transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <a
              href="#notes"
              className="block px-3 py-2 text-sm font-medium text-muted-foreground rounded-lg hover:bg-muted transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Notes
            </a>
            <a
              href="#lectures"
              className="block px-3 py-2 text-sm font-medium text-muted-foreground rounded-lg hover:bg-muted transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Lectures
            </a>
            <a
              href="#progress"
              className="block px-3 py-2 text-sm font-medium text-muted-foreground rounded-lg hover:bg-muted transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Progress
            </a>
            <div className="pt-3 border-t border-border space-y-2">
              {user ? (
                <>
                  <Button asChild variant="outline" className="w-full" size="sm">
                    <Link href="/dashboard" onClick={() => setIsMenuOpen(false)}>
                      <User className="w-4 h-4 mr-2" />
                      Dashboard
                    </Link>
                  </Button>
                  <Button className="w-full" size="sm" onClick={handleSignOut}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign out
                  </Button>
                </>
              ) : (
                <>
                  <Button asChild variant="outline" className="w-full" size="sm">
                    <Link href="/auth?mode=login" onClick={() => setIsMenuOpen(false)}>Log in</Link>
                  </Button>
                  <Button asChild className="w-full" size="sm">
                    <Link href="/auth?mode=signup" onClick={() => setIsMenuOpen(false)}>Sign up</Link>
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
