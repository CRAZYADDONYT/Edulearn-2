import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, Video, GraduationCap } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-accent/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-muted rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-card rounded-full border border-border mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <span className="w-2 h-2 bg-accent rounded-full animate-pulse" />
            <span className="text-sm text-muted-foreground">Quality learning materials, curated by experts</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-balance animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
            Learn smarter,
            <span className="block mt-2">not harder</span>
          </h1>

          <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
            Access beautifully organized notes and engaging video lectures.
            All content is carefully curated and added by our team for your success.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-300">
            <Button asChild size="lg" className="group px-8 h-12 text-base font-medium">
              <Link href="/auth">
                Get started free
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="px-8 h-12 text-base font-medium">
              <a href="#notes">
                <BookOpen className="mr-2 w-4 h-4" />
                Explore content
              </a>
            </Button>
          </div>

          <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-12 duration-700 delay-500">
            <div className="flex flex-col items-center gap-3 p-4 rounded-xl bg-card border border-border">
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-accent" />
              </div>
              <div className="text-center">
                <div className="font-semibold text-foreground">Curated Notes</div>
                <div className="text-sm text-muted-foreground mt-1">Expert-crafted materials</div>
              </div>
            </div>
            <div className="flex flex-col items-center gap-3 p-4 rounded-xl bg-card border border-border">
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                <Video className="w-5 h-5 text-accent" />
              </div>
              <div className="text-center">
                <div className="font-semibold text-foreground">Video Lectures</div>
                <div className="text-sm text-muted-foreground mt-1">Learn at your pace</div>
              </div>
            </div>
            <div className="flex flex-col items-center gap-3 p-4 rounded-xl bg-card border border-border">
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-accent" />
              </div>
              <div className="text-center">
                <div className="font-semibold text-foreground">Made for learners</div>
                <div className="text-sm text-muted-foreground mt-1">Simple, focused, clear</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
